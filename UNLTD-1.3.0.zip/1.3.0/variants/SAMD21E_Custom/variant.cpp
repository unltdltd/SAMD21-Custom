/*
 * +------------+------------------+--------+-----------------+--------------------------------------------------------------------------------------------------------
 * + Pin number + Board pin        |  PIN   | Label/Name      | Comments (* is for default peripheral in use)
 * +------------+------------------+--------+-----------------+--------------------------------------------------------------------------------------------------------
 * |            | Digital Low      |        |                 |
 * +------------+------------------+--------+-----------------+--------------------------------------------------------------------------------------------------------
 * | 0          | ~0               |  PA17  | PWM1            | EIC/EXTINT[1]                        PTC/X[5] +SERCOM1/PAD[1]  SERCOM3/PAD[1] *TCC2/WO[1]  TCC0/WO[7]
 * | 1          | ~1               |  PA15  | PWM2            | EIC/EXTINT[15]                                 SERCOM2/PAD[3]  SERCOM4/PAD[3] *TC3/WO[1]   TCC0/WO[5]
 * | 2          | ~2               |  PA14  | PWM3            | EIC/EXTINT[14]                                 SERCOM2/PAD[2]  SERCOM4/PAD[2]  TC3/WO[0]  *TCC0/WO[4]
 * | 3          | ~3               |  PA11  | PWM4            | EIC/EXTINT[11] ADC/AIN[19]           PTC/X[3]  SERCOM0/PAD[3]  SERCOM2/PAD[3] *TCC0/WO[3]  TCC1/WO[1]
 * | 4          | ~4               |  PA07  | PWM5            | EIC/EXTINT[7]  ADC/AIN[7]  AC/AIN[3] PTC/Y[5]  SERCOM0/PAD[3]                 *TCC1/WO[1]
 * | 5          | ~5               |  PA08  | PWM6            | EIC/NMI        ADC/AIN[16]           PTC/X[0]  SERCOM0/PAD[0]  SERCOM2/PAD[0]  TCC0/WO[0] *TCC1/WO[2]
 * | 6          | ~6               |  PA09  | PWM7            | EIC/EXTINT[9]  ADC/AIN[17]           PTC/X[1]  SERCOM0/PAD[1]  SERCOM2/PAD[1] *TCC0/WO[1]  TCC1/WO[3]
 * | 7          | ~7               |  PA10  | PWM8/LED        | EIC/EXTINT[10] ADC/AIN[18]           PTC/X[2]  SERCOM0/PAD[2]                 *TCC0/WO[2]  TCC1/WO[0]
 * +------------+------------------+--------+-----------------+--------------------------------------------------------------------------------------------------------
 * |            | Digital High     |        |                 |
 * +------------+------------------+--------+-----------------+--------------------------------------------------------------------------------------------------------
 * | 8          | 8                |  PA23  | IRQ             | EIC/EXTINT[7]                        PTC/X[11] SERCOM3/PAD[1] *SERCOM5/PAD[1]  TC4/WO[1]   TCC0/WO[5]
 * | 9          | 9                |  PA22  | IRQ2            | EIC/EXTINT[6]                        PTC/X[10] SERCOM3/PAD[0] *SERCOM5/PAD[0]  TC4/WO[0]   TCC0/WO[4]
 * | 10         | 10               |  PA27  | CS              | **LITERALLY NOTHING HERE. JUST A GPIO
 * | 11         | 11               |  PA16  | SPI2_MISO       | EIC/EXTINT[0]                        PTC/X[4]  SERCOM1/PAD[0] *SERCOM3/PAD[0]  TCC2/WO[0]  TCC0/WO[6]
 * | 12         | 12               |  PA18  | SPI2_MOSI       | EIC/EXTINT[2]                        PTC/X[6]  SERCOM1/PAD[2] *SERCOM3/PAD[2]  TC3/WO[0]   TCC0/WO[2]
 * | 13         | 13               |  PA19  | SPI2_SCK        | EIC/EXTINT[3]                        PTC/X[7]  SERCOM1/PAD[3] *SERCOM3/PAD[3]  TC3/WO[1]   TCC0/WO[3]
 * | 14         | 14               |  PA31  | PWM10?          |                                                                SERCOM1/PAD[3]  TCC1/WO[1]
 * | 15         | 15               |  PA30  | PWM9            |                                                                SERCOM1/PAD[2]  TCC1/WO[0]
 * +------------+------------------+--------+-----------------+--------------------------------------------------------------------------------------------------------
 * |            | Digital Extended |        |                 |
 * +------------+------------------+--------+-----------------+--------------------------------------------------------------------------------------------------------
 * | 16         | 16               |  PA02  | A0              | EIC/EXTINT[2]  ADC/AIN[0]  DAC/VOUT  PTC/Y[0]
 * | 17         | 17               |  PA04  | A1              | EIC/EXTINT[4]  ADC/AIN[4]  AC/AIN[0] PTC/Y[2]  *SERCOM0/PAD[0]                  TCC0/WO[0]
 * | 18         | 18               |  PA05  | A2              | EIC/EXTINT[5]  ADC/AIN[5]  AC/AIN[1] PTC/Y[5]  *SERCOM0/PAD[1]                  TCC0/WO[1]
 * | 19         | 19               |  PA06  | A3              | EIC/EXTINT[6]  ADC/AIN[6]  AC/AIN[2] PTC/Y[4]  *SERCOM0/PAD[2]                  TCC1/WO[0]
 * +------------+------------------+--------+-----------------+--------------------------------------------------------------------------------------------------------
 * |            | Analog Connector |        |                 |
 * +------------+------------------+--------+-----------------+--------------------------------------------------------------------------------------------------------
 * | 20         | A0               |  PA02  | A0              | EIC/EXTINT[2] *ADC/AIN[0]  DAC/VOUT  PTC/Y[0]
 * | 21         | A1               |  PA04  | A1              | EIC/EXTINT[4] *ADC/AIN[4]  AC/AIN[0] PTC/Y[2]  SERCOM0/PAD[0]                  TCC0/WO[0]
 * | 22         | A2               |  PA06  | A2              | EIC/EXTINT[6] *ADC/AIN[6]  AC/AIN[2] PTC/Y[4]  SERCOM0/PAD[2]                  TCC1/WO[0]
 * | 23         | A3               |  PA05  | A3              | EIC/EXTINT[5] *ADC/AIN[5]  AC/AIN[1] PTC/Y[5]  SERCOM0/PAD[1]                  TCC0/WO[1]
 * | 24         | A4               |  PA03  |                 | EIC/EXTINT[3] [ADC|DAC]/VREFA *ADC/AIN[1] PTC/Y[1]
 * +------------+------------------+--------+-----------------+--------------------------------------------------------------------------------------------------------
 * |            | Wire             |        |                 | **SHARED WITH IRQ and IRQ2
 * +------------+------------------+--------+-----------------+--------------------------------------------------------------------------------------------------------
 * | 25         | SDA              |  PA22  | SDA             | Pin 8
 * | 26         | SCL              |  PA23  | SCL             | Pin 9
 * +------------+------------------+--------+-----------------+--------------------------------------------------------------------------------------------------------
 * |            | SPI              |        |                 |
 * +------------+------------------+--------+-----------------+--------------------------------------------------------------------------------------------------------
 * | 27         | DS_D             |  PA00  | DS_MOSI         | EIC/EXTINT[0]                                                 *SERCOM1/PAD[0]  TCC2/WO[0]
 * | 28         | DS_C             |  PA01  | DS_SCK          | EIC/EXTINT[1]                                                 *SERCOM1/PAD[1]  TCC2/WO[1]
 * | 29         | MISO             |  PA31  | DS_MISO         |                                                                SERCOM1/PAD[3]  TCC1/WO[1]
 * | 30         | MISO             |  PA16  | SPI2_MISO       | Pin 11
 * | 31         | MOSI             |  PA18  | SPI2_MOSI       | Pin 12
 * | 32         | SCK              |  PA19  | SPI2_SCK        | Pin 13
 * | 33         | A1/MOSI          |  PA04  | SPI_MOSI        | Pin 17/A1
 * | 34         | A3/SCK           |  PA05  | SPI_SCK         | Pin 19/A3
 * | 35         | A2/MISO          |  PA06  | SPI_MISO        | Pin 18/A2
 * +------------+------------------+--------+-----------------+--------------------------------------------------------------------------------------------------------
 * |            | LEDs             |        |                 | **NO DEDICATED LEDS
 * +------------+------------------+--------+-----------------+--------------------------------------------------------------------------------------------------------
 * | 36         | ~1               |  PA15  | PWM2            | Pin 1
 * | 37         | ~2               |  PA14  | PWM3            | Pin 2
 * +------------+------------------+--------+-----------------+--------------------------------------------------------------------------------------------------------
 * |            | USB              |        |                 |
 * +------------+------------------+--------+-----------------+--------------------------------------------------------------------------------------------------------
 * | 38         |                  |  PA28  | USB_HOST_ENABLE | EIC/EXTINT[8]
 * | 39         |                  |  PA24  | USB_NEGATIVE    | *USB/DM
 * | 40         |                  |  PA25  | USB_POSITIVE    | *USB/DP
 * +------------+------------------+--------+-----------------+--------------------------------------------------------------------------------------------------------
 * |            | Extra UART       |        |                 | SHARED WITH OTHER I/O
 * +------------+------------------+--------+-----------------+--------------------------------------------------------------------------------------------------------
 * | 41         | TX               |  PA22  | TX              | Pin 8/*SHARED WITH IRQ
 * | 42         | RX               |  PA23  | RX              | Pin 9/*SHARED WITH IRQ2
 * | 43         | 17               |  PA04  | TX_2            | Pin 17/*SHARED WITH A1
 * | 44         | 19               |  PA05  | TX_2            | Pin 19*SHARED WITH A3
 * | 45         | MOSI             |  PA00  | TX_3            | *SHARED WITH DS_MOSI
 * | 46         | SCK              |  PA01  | RX_3            | *SHARED WITH DS_SCK
 * +------------+------------------+--------+-----------------+--------------------------------------------------------------------------------------------------------
 * | 47         | AREF             |  PA03  |                 | EIC/EXTINT[3] [ADC|DAC]/VREFA ADC/AIN[1] PTC/Y[1]
 * +------------+------------------+--------+-----------------+--------------------------------------------------------------------------------------------------------
 * | 48         | A0               |  PA02  | DAC             | EIC/EXTINT[2] ADC/AIN[0]  DAC/VOUT  PTC/Y[0]
 * +------------+------------------+--------+-----------------+--------------------------------------------------------------------------------------------------------
 * |            | SWx              |        |                 |
 * +------------+------------------+--------+-----------------+--------------------------------------------------------------------------------------------------------
 * | 49         | SWC              |  PA30  | SWCLK           | Pin 14
 * | 50         | SWD              |  PA31  | SWDIO           | Pin 15
 */


#include "variant.h"

/*
 * Pins descriptions
 * UNLTD SAMD21E Custom
 */

 const PinDescription g_APinDescription[]=
 {
 // 0.. 15 - GPIO Digital Pins
 // --------------------------
 // 0..7
 // Digital Low - PWM OUTPUTS - Exposed on DF13 Connector as Transisted outputs
 { PORTA, 17, PIO_TIMER, (PIN_ATTR_DIGITAL|PIN_ATTR_PWM|PIN_ATTR_TIMER), No_ADC_Channel, PWM2_CH1, TCC2_CH1, EXTERNAL_INT_1 }, // 13 TCC2/WO[1]
 { PORTA, 15, PIO_TIMER, (PIN_ATTR_DIGITAL|PIN_ATTR_PWM|PIN_ATTR_TIMER), No_ADC_Channel, PWM3_CH1, TC3_CH1, EXTERNAL_INT_15 }, // TC3/WO[1]
 { PORTA, 14, PIO_TIMER_ALT, (PIN_ATTR_DIGITAL|PIN_ATTR_PWM|PIN_ATTR_TIMER_ALT), No_ADC_Channel, PWM0_CH4, TCC0_CH4, EXTERNAL_INT_14 },
 { PORTA, 11, PIO_TIMER_ALT, (PIN_ATTR_DIGITAL|PIN_ATTR_PWM|PIN_ATTR_TIMER_ALT), No_ADC_Channel, PWM0_CH3, TCC0_CH3, EXTERNAL_INT_11 }, // RX: SERCOM0/PAD[3]
 { PORTA,  7, PIO_TIMER, (PIN_ATTR_DIGITAL|PIN_ATTR_PWM|PIN_ATTR_TIMER), No_ADC_Channel, PWM1_CH1, TCC1_CH1, EXTERNAL_INT_7 }, // 9 TCC1/WO[1]
 { PORTA,  8, PIO_TIMER_ALT, (PIN_ATTR_DIGITAL|PIN_ATTR_PWM|PIN_ATTR_TIMER_ALT), No_ADC_Channel, PWM1_CH2, TCC1_CH2, EXTERNAL_INT_NMI },  // TCC0/WO[0]
 { PORTA,  9, PIO_TIMER, (PIN_ATTR_DIGITAL|PIN_ATTR_PWM|PIN_ATTR_TIMER), No_ADC_Channel, PWM0_CH1, TCC0_CH1, EXTERNAL_INT_9 }, // TCC0/WO[1]
 // 7 (LED) - Onboard LED
 { PORTA, 10, PIO_TIMER_ALT, (PIN_ATTR_DIGITAL|PIN_ATTR_PWM|PIN_ATTR_TIMER_ALT), No_ADC_Channel, PWM0_CH2, TCC0_CH2, EXTERNAL_INT_10 }, // TX: SERCOM0/PAD[2]

 // 8..15
 // Digital High - Exposed on external pads
 { PORTA, 23, PIO_SERCOM_ALT, PIN_ATTR_DIGITAL, No_ADC_Channel, NOT_ON_PWM, NOT_ON_TIMER, EXTERNAL_INT_7 }, // SCL: SERCOM5/PAD[1] - TRQ
 { PORTA, 22, PIO_SERCOM_ALT, PIN_ATTR_DIGITAL, No_ADC_Channel, NOT_ON_PWM, NOT_ON_TIMER, EXTERNAL_INT_6 }, // SDA: SERCOM5/PAD[0] - IRQ2
 { PORTA, 27, PIO_OUTPUT, PIN_ATTR_DIGITAL, No_ADC_Channel, NOT_ON_PWM, NOT_ON_TIMER, EXTERNAL_INT_NONE }, // used as output only - CS2
 { PORTA, 16, PIO_SERCOM_ALT, PIN_ATTR_DIGITAL, No_ADC_Channel, NOT_ON_PWM, NOT_ON_TIMER, EXTERNAL_INT_0 }, // SERCOM3/PAD[0] - DEFAULT SPI MISO
 { PORTA, 18, PIO_SERCOM_ALT, PIN_ATTR_DIGITAL, No_ADC_Channel, NOT_ON_PWM, NOT_ON_TIMER, EXTERNAL_INT_2 }, // SERCOM3/PAD[2] - DEFAULT SPI MOSI
 { PORTA, 19, PIO_SERCOM_ALT, PIN_ATTR_DIGITAL, No_ADC_Channel, NOT_ON_PWM, NOT_ON_TIMER, EXTERNAL_INT_3 }, // SERCOM3/PAD[3] - DEFAULT SPI SCK
 { PORTA, 31, PIO_TIMER, PIN_ATTR_DIGITAL, No_ADC_Channel, NOT_ON_PWM, NOT_ON_TIMER, EXTERNAL_INT_NONE }, //(SWDIO)/PWm10? for 2 motor PWM?
 { PORTA, 30, PIO_TIMER, (PIN_ATTR_DIGITAL|PIN_ATTR_PWM|PIN_ATTR_TIMER), No_ADC_Channel, PWM1_CH0, TCC1_CH0, EXTERNAL_INT_NONE }, //(SWCLK)/PWM9

 // 16..19
 // Digital Extended - Exposed on external pads - Alternate Digital use to ADC
 { PORTA,  2, PIO_DIGITAL, (PIN_ATTR_ANALOG|PIN_ATTR_DIGITAL), ADC_Channel0, NOT_ON_PWM, NOT_ON_TIMER, EXTERNAL_INT_2 }, // ADC/AIN[0]
 { PORTA,  4, PIO_SERCOM_ALT, (PIN_ATTR_ANALOG|PIN_ATTR_DIGITAL), ADC_Channel4, NOT_ON_PWM, NOT_ON_TIMER, EXTERNAL_INT_4 }, // SERCOM0/PAD[0]
 { PORTA,  6, PIO_SERCOM_ALT, (PIN_ATTR_ANALOG|PIN_ATTR_DIGITAL), ADC_Channel6,NOT_ON_PWM, NOT_ON_TIMER, EXTERNAL_INT_6 }, // SERCOM0/PAD[2]
 { PORTA,  5, PIO_SERCOM_ALT, (PIN_ATTR_ANALOG|PIN_ATTR_DIGITAL), ADC_Channel5, NOT_ON_PWM, NOT_ON_TIMER, EXTERNAL_INT_5 }, // SERCOM0/PAD[1]

 // 20..24 - Analog Pins
 // A0, Same as D16
 { PORTA,  2, PIO_ANALOG, PIN_ATTR_ANALOG, ADC_Channel0, NOT_ON_PWM, NOT_ON_TIMER, EXTERNAL_INT_2 }, // ADC/AIN[0]
 // A1, Same as D17
 { PORTA,  4, PIO_ANALOG, (PIN_ATTR_ANALOG|PIN_ATTR_DIGITAL), ADC_Channel4, NOT_ON_PWM, NOT_ON_TIMER, EXTERNAL_INT_4 }, // ADC/AIN[4]
 // A2, Same as D19
 { PORTA,  5, PIO_ANALOG, (PIN_ATTR_ANALOG|PIN_ATTR_DIGITAL), ADC_Channel5, NOT_ON_PWM, NOT_ON_TIMER, EXTERNAL_INT_5 }, // ADC/AIN[5]
 // A3, Same as D18
 { PORTA,  6, PIO_ANALOG, (PIN_ATTR_ANALOG|PIN_ATTR_DIGITAL), ADC_Channel6, NOT_ON_PWM, NOT_ON_TIMER, EXTERNAL_INT_6 }, // ADC/AIN[6]
 // A4
 { PORTA,  3, PIO_ANALOG, (PIN_ATTR_ANALOG|PIN_ATTR_DIGITAL), ADC_Channel1, NOT_ON_PWM, NOT_ON_TIMER, EXTERNAL_INT_3 }, // ADC/AIN[1]
 // 25..26 - I2C pins (SDA/SCL)
 // Same as D8 but on Sercom5
 { PORTA, 22, PIO_SERCOM_ALT, PIN_ATTR_DIGITAL, No_ADC_Channel, NOT_ON_PWM, NOT_ON_TIMER, EXTERNAL_INT_6 }, // SDA: SERCOM5/PAD[0]
 // Same as D9 but on Sercom5
 { PORTA, 23, PIO_SERCOM_ALT, PIN_ATTR_DIGITAL, No_ADC_Channel, NOT_ON_PWM, NOT_ON_TIMER, EXTERNAL_INT_7 }, // SCL: SERCOM5/PAD[1]

 // 27..35 - SPI Pins (MISO,MOSI,SCK)
 // Internal Dotstar Data/Clock - Also on DF13 Connector to control external Dotstar - SPI_DS
 { PORTA,  0, PIO_SERCOM_ALT, PIN_ATTR_NONE, ADC_Channel4, NOT_ON_PWM, NOT_ON_TIMER, EXTERNAL_INT_4 }, // MOSI: SEROM1/PAD[0]
 { PORTA,  1, PIO_SERCOM_ALT, PIN_ATTR_NONE, ADC_Channel5, NOT_ON_PWM, NOT_ON_TIMER, EXTERNAL_INT_5 }, // SCK: SERCOM1/PAD[1]
 //Same as D14/SWDIO
 { PORTA, 31, PIO_SERCOM_ALT, PIN_ATTR_NONE, No_ADC_Channel, NOT_ON_PWM, NOT_ON_TIMER, EXTERNAL_INT_NONE }, //MISO: SERCOM1/PAD[3]
 // Same as 11 but on Sercom3 - ALT_SPI - MAX6957
 { PORTA, 16, PIO_SERCOM_ALT, PIN_ATTR_DIGITAL, No_ADC_Channel, NOT_ON_PWM, NOT_ON_TIMER, EXTERNAL_INT_0 }, // MISO-SERCOM3/PAD[0]
 // Same as 12 but on Sercom3 - ALT_SPI - MAX6957
 { PORTA, 18, PIO_SERCOM_ALT, PIN_ATTR_DIGITAL, No_ADC_Channel, NOT_ON_PWM, NOT_ON_TIMER, EXTERNAL_INT_2 }, // MOSI-SERCOM3/PAD[2]
 // Same as 13 but on Sercom3 - ALT_SPI - MAX6957
 { PORTA, 19, PIO_SERCOM_ALT, PIN_ATTR_DIGITAL, No_ADC_Channel, NOT_ON_PWM, NOT_ON_TIMER, EXTERNAL_INT_3 }, // CLK-SERCOM3/PAD[3]
 // Same as D17 but on Sercom0 - DEFAULT SPI (CRMX, RFM69HCW)
 { PORTA,  4, PIO_SERCOM_ALT, (PIN_ATTR_ANALOG|PIN_ATTR_DIGITAL), ADC_Channel4, NOT_ON_PWM, NOT_ON_TIMER, EXTERNAL_INT_4 }, // MOSI: SERCOM0/PAD[0]
 // Same as D19 but on Sercom0 - DEFAULT SPI (CRMX, RFM69HCW)
 { PORTA,  5, PIO_SERCOM_ALT, (PIN_ATTR_ANALOG|PIN_ATTR_DIGITAL), ADC_Channel5, NOT_ON_PWM, NOT_ON_TIMER, EXTERNAL_INT_5 }, // SCK: SERCOM0/PAD[1]
 // Same as D18 but on Sercom0 - DEFAULT SPI (CRMX, RFM69HCW)
 { PORTA,  6, PIO_SERCOM_ALT, (PIN_ATTR_ANALOG|PIN_ATTR_DIGITAL), ADC_Channel6,NOT_ON_PWM, NOT_ON_TIMER, EXTERNAL_INT_6 }, // MISO: SERCOM0/PAD[2]

 // 36..37 - TX/RX LEDS
 // Same as D1
 { PORTA, 15, PIO_TIMER, (PIN_ATTR_DIGITAL|PIN_ATTR_PWM|PIN_ATTR_TIMER), No_ADC_Channel, PWM3_CH1, TC3_CH1, EXTERNAL_INT_15 }, // RX
 // Same as D2
 { PORTA, 14, PIO_TIMER_ALT, (PIN_ATTR_DIGITAL|PIN_ATTR_PWM|PIN_ATTR_TIMER), No_ADC_Channel, PWM0_CH4, TCC0_CH4, EXTERNAL_INT_14 }, // TX

 // 38..40 - USB
 // ----------------------------
 { PORTA, 28, PIO_COM, PIN_ATTR_NONE, No_ADC_Channel, NOT_ON_PWM, NOT_ON_TIMER, EXTERNAL_INT_NONE }, // USB Host enable
 { PORTA, 24, PIO_COM, PIN_ATTR_NONE, No_ADC_Channel, NOT_ON_PWM, NOT_ON_TIMER, EXTERNAL_INT_NONE }, // USB/DM
 { PORTA, 25, PIO_COM, PIN_ATTR_NONE, No_ADC_Channel, NOT_ON_PWM, NOT_ON_TIMER, EXTERNAL_INT_NONE }, // USB/DP

 // 41..46 - Extra UART
 // Same as D8 but on Sercom5
 { PORTA, 22, PIO_SERCOM_ALT, PIN_ATTR_DIGITAL, No_ADC_Channel, NOT_ON_PWM, NOT_ON_TIMER, EXTERNAL_INT_6 }, // TX: SERCOM5/PAD[0]
 // Same as D9 but on Sercom5
 { PORTA, 23, PIO_SERCOM_ALT, PIN_ATTR_DIGITAL, No_ADC_Channel, NOT_ON_PWM, NOT_ON_TIMER, EXTERNAL_INT_7 }, // RX: SERCOM5/PAD[1]
 // A1, Same as D17
 { PORTA,  4, PIO_SERCOM, (PIN_ATTR_ANALOG|PIN_ATTR_DIGITAL), ADC_Channel4, NOT_ON_PWM, NOT_ON_TIMER, EXTERNAL_INT_4 }, // TX: SERCOM0/PAD[0]
 // A2, Same as D19
 { PORTA,  5, PIO_SERCOM_ALT, (PIN_ATTR_ANALOG|PIN_ATTR_DIGITAL), ADC_Channel5, NOT_ON_PWM, NOT_ON_TIMER, EXTERNAL_INT_5 }, // RX: SERCOM0/PAD[1]
 // SAME as INTERNAL DS SPI PINS on external DF13 connector
 { PORTA,  0, PIO_SERCOM_ALT, PIN_ATTR_NONE, ADC_Channel4, NOT_ON_PWM, NOT_ON_TIMER, EXTERNAL_INT_4 }, // TX: SEROM1/PAD[0]
 { PORTA,  1, PIO_SERCOM_ALT, PIN_ATTR_NONE, ADC_Channel5, NOT_ON_PWM, NOT_ON_TIMER, EXTERNAL_INT_5 }, // RX: SERCOM1/PAD[1]

 // 47 - Aref
 { PORTA, 3, PIO_ANALOG, PIN_ATTR_ANALOG, No_ADC_Channel, NOT_ON_PWM, NOT_ON_TIMER, EXTERNAL_INT_NONE }, // DAC/VREFP

 // 48 - Alternate use of A0 (DAC Output)
 { PORTA,  2, PIO_ANALOG, PIN_ATTR_ANALOG, DAC_Channel0, NOT_ON_PWM, NOT_ON_TIMER, EXTERNAL_INT_2 }, // DAC/VOUT

 // GPIO 49 & 50 (SWCLK & SWDIO)
 // --------------------------
 { PORTA, 30, PIO_SERCOM_ALT, PIN_ATTR_NONE, No_ADC_Channel, NOT_ON_PWM, NOT_ON_TIMER, EXTERNAL_INT_NONE },
 { PORTA, 31, PIO_SERCOM_ALT, PIN_ATTR_NONE, No_ADC_Channel, NOT_ON_PWM, NOT_ON_TIMER, EXTERNAL_INT_NONE },

 };

const void* g_apTCInstances[TCC_INST_NUM+TC_INST_NUM]={ TCC0, TCC1, TCC2, TC3, TC4, TC5 } ;

// Multi-serial objects instantiation
// Only 0-3 available on E variant!!
SERCOM sercom0( SERCOM0 ) ;
SERCOM sercom1( SERCOM1 ) ;
SERCOM sercom2( SERCOM2 ) ;
SERCOM sercom3( SERCOM3 ) ;


Uart Serial1( &sercom0, PIN_SERIAL1_RX, PIN_SERIAL1_TX, PAD_SERIAL1_RX, PAD_SERIAL1_TX ) ;
Uart Serial2( &sercom1, PIN_SERIAL2_RX, PIN_SERIAL2_TX, PAD_SERIAL2_RX, PAD_SERIAL2_TX ) ;
Uart Serial3( &sercom3, PIN_SERIAL3_RX, PIN_SERIAL3_TX, PAD_SERIAL3_RX, PAD_SERIAL3_TX ) ;

void SERCOM0_Handler()
{
  Serial1.IrqHandler();
}
