/*
 * +------------+------------------+--------+-----------------+--------------------------------------------------------------------------------------------------------
 * + Pin number + Board pin        |  PIN   | Label/Name      | Comments (* is for default peripheral in use)
 * +------------+------------------+--------+-----------------+--------------------------------------------------------------------------------------------------------
 * |            | Digital Low      |        |                 |
 * +------------+------------------+--------+-----------------+--------------------------------------------------------------------------------------------------------
 * | 0          | ~0               |  PA17  | PWM1            | EIC/EXTINT[1]                        PTC/X[5] +SERCOM1/PAD[1]  SERCOM3/PAD[1] *TCC2/WO[1]  TCC0/WO[7]
 * | 1          | ~1               |  PA15  | PWM2            | EIC/EXTINT[15]                                 SERCOM2/PAD[3]  SERCOM4/PAD[3] *TC3/WO[1]   TCC0/WO[5]
 * | 2          | ~2               |  PA14  | PWM3            | EIC/EXTINT[14]                                 SERCOM2/PAD[2]  SERCOM4/PAD[2]  TC3/WO[0]  *TCC0/WO[4]
 * | 3          | ~3               |  PA10  | PWM4/LED        | EIC/EXTINT[10] ADC/AIN[18]           PTC/X[2]  SERCOM0/PAD[2]                 *TCC0/WO[2]  TCC1/WO[0]
 * | 4          | ~4               |  PA30  | PWM9            |                                                                SERCOM1/PAD[2] *TCC1/WO[0]
 * | 5          | ~5               |  PA31  | LINK            |                                                                SERCOM1/PAD[3]  TCC1/WO[1]
 * | 6          | ~6               |  PA23  | INT             | EIC/EXTINT[7]                        PTC/X[11] SERCOM3/PAD[1] *SERCOM5/PAD[1]  TC4/WO[1]   TCC0/WO[5]
 * | 7          | ~7               |  PA22  | RST             | EIC/EXTINT[6]                        PTC/X[10] SERCOM3/PAD[0] *SERCOM5/PAD[0]  TC4/WO[0]   TCC0/WO[4]
 * +------------+------------------+--------+-----------------+--------------------------------------------------------------------------------------------------------
 * |            | Digital High     |        |                 |
 * +------------+------------------+--------+-----------------+--------------------------------------------------------------------------------------------------------
 * | 8          | 8                |  PA27  | CS2             | EIC/EXTINT[8] **LITERALLY NOTHING HERE. JUST A GPIO
 * | 9          | 9                |  PA28  | CS              | EIC/EXTINT[8] **LITERALLY NOTHING HERE. JUST A GPIO
 * | 10         | 10               |  PA16  | SPI2_MISO       | EIC/EXTINT[0]                        PTC/X[4]  SERCOM1/PAD[0] *SERCOM3/PAD[0]  TCC2/WO[0]  TCC0/WO[6]
 * | 11         | 11               |  PA18  | SPI2_MOSI       | EIC/EXTINT[2]                        PTC/X[6]  SERCOM1/PAD[2] *SERCOM3/PAD[2]  TC3/WO[0]   TCC0/WO[2]
 * | 12         | 12               |  PA19  | SPI2_SCK        | EIC/EXTINT[3]                        PTC/X[7]  SERCOM1/PAD[3] *SERCOM3/PAD[3]  TC3/WO[1]   TCC0/WO[3]
 * +------------+------------------+--------+-----------------+--------------------------------------------------------------------------------------------------------
 * |            | Digital Extended |        |                 |
 * +------------+------------------+--------+-----------------+--------------------------------------------------------------------------------------------------------
 *
 * +------------+------------------+--------+-----------------+--------------------------------------------------------------------------------------------------------
 * |            | Analog Connector |        |                 |
 * +------------+------------------+--------+-----------------+--------------------------------------------------------------------------------------------------------
 * | 13         | A0               |  PA02  | A0              | EIC/EXTINT[2] *ADC/AIN[0]  DAC/VOUT  PTC/Y[0]
 * | 14         | A1               |  PA04  | A1              | EIC/EXTINT[4] *ADC/AIN[4]  AC/AIN[0] PTC/Y[2]  SERCOM0/PAD[0]                  TCC0/WO[0]
 * | 15         | A2               |  PA05  | A2              | EIC/EXTINT[5] *ADC/AIN[5]  AC/AIN[1] PTC/Y[5]  SERCOM0/PAD[1]                  TCC0/WO[1]
 * | 16         | A3               |  PA06  | A3              | EIC/EXTINT[6] *ADC/AIN[6]  AC/AIN[2] PTC/Y[4]  SERCOM0/PAD[2]                  TCC1/WO[0]
 * | 17         | A4               |  PA07  | A4              |
 * | 18         | A5               |  PA03  | A5              | EIC/EXTINT[3] [ADC|DAC]/VREFA *ADC/AIN[1] PTC/Y[1]
// * | 26         | A6               |  PA00  | A6              | EIC/EXTINT[0]                                                 *SERCOM1/PAD[0]  TCC2/WO[0]
// * | 27         | A7               |  PA01  | A7              | EIC/EXTINT[1]                                                 *SERCOM1/PAD[1]  TCC2/WO[1]
 * +------------+------------------+--------+-----------------+--------------------------------------------------------------------------------------------------------
 * |            | Wire             |        |                 | **SHARED WITH IRQ and IRQ2
 * +------------+------------------+--------+-----------------+--------------------------------------------------------------------------------------------------------
 *
 * +------------+------------------+--------+-----------------+--------------------------------------------------------------------------------------------------------
 * |            | SPI              |        |                 |
 * +------------+------------------+--------+-----------------+--------------------------------------------------------------------------------------------------------
 * | 19         | DS_D             |  PA00  | DS_MOSI         | EIC/EXTINT[0]                                                 *SERCOM1/PAD[0]  TCC2/WO[0]
 * | 20         | DS_C             |  PA01  | DS_SCK          | EIC/EXTINT[1]                                                 *SERCOM1/PAD[1]  TCC2/WO[1]
 * | 21         | DS_MISO          |  PA31  | DS_MISO         |                                                                SERCOM1/PAD[3]  TCC1/WO[1]
 * | 22         | SPI2_MISO        |  PA16  | SPI2_MISO       | Pin 10
 * | 23         | SPI2_MOSI        |  PA18  | SPI2_MOSI       | Pin 11
 * | 24         | SPI2_SCK         |  PA19  | SPI2_SCK        | Pin 12
 * | 25         | MOSI             |  PA08  | SPI_MOSI        | EIC/NMI        ADC/AIN[16]           PTC/X[0] *SERCOM0/PAD[0]  SERCOM2/PAD[0]  TCC0/WO[0]  TCC1/WO[2]
 * | 26         | SCK              |  PA09  | SPI_SCK         | EIC/EXTINT[9]  ADC/AIN[17]           PTC/X[1] *SERCOM0/PAD[1]  SERCOM2/PAD[1]  TCC0/WO[1]  TCC1/WO[3]
 * | 27         | MISO             |  PA011 | SPI_MISO        | EIC/EXTINT[11] ADC/AIN[19]           PTC/X[3] *SERCOM0/PAD[3]  SERCOM2/PAD[3]  TCC0/WO[3]  TCC1/WO[1]
 * +------------+------------------+--------+-----------------+--------------------------------------------------------------------------------------------------------
 * |            | LEDs             |        |                 | **NO DEDICATED LEDS
 * +------------+------------------+--------+-----------------+--------------------------------------------------------------------------------------------------------
 * | 28         | ~3               |  PA10  | PWM4/LED        | Pin 3
 * | 29         | 5                |  PA31  | LINK            | Pin 5
 * +------------+------------------+--------+-----------------+--------------------------------------------------------------------------------------------------------
 * |            | USB              |        |                 |
 * +------------+------------------+--------+-----------------+--------------------------------------------------------------------------------------------------------
 * | 30         |                  |  PA28  | USB_HOST_ENABLE | EIC/EXTINT[8]
 * | 31         |                  |  PA24  | USB_NEGATIVE    | *USB/DM
 * | 32         |                  |  PA25  | USB_POSITIVE    | *USB/DP
 * +------------+------------------+--------+-----------------+--------------------------------------------------------------------------------------------------------
 * |            | Extra UART       |        |                 | SHARED WITH OTHER I/O
 * +------------+------------------+--------+-----------------+--------------------------------------------------------------------------------------------------------
 *
 * +------------+------------------+--------+-----------------+--------------------------------------------------------------------------------------------------------
 * | 33         | AREF             |  PA03  |                 | EIC/EXTINT[3] [ADC|DAC]/VREFA ADC/AIN[1] PTC/Y[1]
 * +------------+------------------+--------+-----------------+--------------------------------------------------------------------------------------------------------
 * | 34         | A0               |  PA02  | DAC             | EIC/EXTINT[2] ADC/AIN[0]  DAC/VOUT  PTC/Y[0]
 * +------------+------------------+--------+-----------------+--------------------------------------------------------------------------------------------------------
 * |            | SWx              |        |                 |
 * +------------+------------------+--------+-----------------+--------------------------------------------------------------------------------------------------------
 * | 35         | SWC              |  PA30  | SWCLK           | Pin 14
 * | 36         | SWD              |  PA31  | SWDIO           | Pin 15
 */

#include "variant.h"

/*
 * Pins descriptions
 */
/*
 * UNLTD SAMD21E RF Remote
 */

 const PinDescription g_APinDescription[]=
 {
 // 0.. 15 - GPIO Digital Pins
 // --------------------------
 // 0..7
 // Digital Low - PWM OUTPUTS - Exposed on DF13 Connector as Transisted outputs
 { PORTA, 17, PIO_TIMER, (PIN_ATTR_DIGITAL|PIN_ATTR_PWM|PIN_ATTR_TIMER), No_ADC_Channel, PWM2_CH1, TCC2_CH1, EXTERNAL_INT_1 }, // 0 TCC2/WO[1]
 { PORTA, 15, PIO_TIMER, (PIN_ATTR_DIGITAL|PIN_ATTR_PWM|PIN_ATTR_TIMER), No_ADC_Channel, PWM3_CH1, TC3_CH1, EXTERNAL_INT_15 }, // 1 TC3/WO[1]
 { PORTA, 14, PIO_TIMER_ALT, (PIN_ATTR_DIGITAL|PIN_ATTR_PWM|PIN_ATTR_TIMER_ALT), No_ADC_Channel, PWM0_CH4, TCC0_CH4, EXTERNAL_INT_14 }, // 2 TCC0/WO[4]
 // 3 (LED) - Onboard LED
 { PORTA, 10, PIO_TIMER_ALT, (PIN_ATTR_DIGITAL|PIN_ATTR_PWM|PIN_ATTR_TIMER_ALT), No_ADC_Channel, PWM0_CH2, TCC0_CH2, EXTERNAL_INT_10 }, // 3/LED TCC0/WO[2]
 { PORTA, 30, PIO_TIMER, (PIN_ATTR_DIGITAL|PIN_ATTR_PWM|PIN_ATTR_TIMER), No_ADC_Channel, PWM1_CH0, TCC1_CH0, EXTERNAL_INT_NONE }, //(SWCLK)/PWM9 TCC1/WO[0]
 { PORTA, 31, PIO_TIMER, PIN_ATTR_DIGITAL, No_ADC_Channel, NOT_ON_PWM, NOT_ON_TIMER, EXTERNAL_INT_NONE }, //(SWDIO) LINK_LED
 { PORTA, 23, PIO_SERCOM_ALT, PIN_ATTR_DIGITAL, No_ADC_Channel, NOT_ON_PWM, NOT_ON_TIMER, EXTERNAL_INT_7 }, // SCL: SERCOM5/PAD[1] - INT
 { PORTA, 22, PIO_SERCOM_ALT, PIN_ATTR_DIGITAL, No_ADC_Channel, NOT_ON_PWM, NOT_ON_TIMER, EXTERNAL_INT_6 }, // SDA: SERCOM5/PAD[0] - RST
 // 8..12
 // Digital High
 { PORTA, 27, PIO_OUTPUT, PIN_ATTR_DIGITAL, No_ADC_Channel, NOT_ON_PWM, NOT_ON_TIMER, EXTERNAL_INT_NONE },  // used as output only - CS2
 { PORTA, 28, PIO_COM, PIN_ATTR_NONE, No_ADC_Channel, NOT_ON_PWM, NOT_ON_TIMER, EXTERNAL_INT_NONE },        // used as output only - CS/USB Host enable
 { PORTA, 16, PIO_SERCOM_ALT, PIN_ATTR_DIGITAL, No_ADC_Channel, NOT_ON_PWM, NOT_ON_TIMER, EXTERNAL_INT_0 }, // SERCOM3/PAD[0] - DEFAULT SPI MISO
 { PORTA, 18, PIO_SERCOM_ALT, PIN_ATTR_DIGITAL, No_ADC_Channel, NOT_ON_PWM, NOT_ON_TIMER, EXTERNAL_INT_2 }, // SERCOM3/PAD[2] - DEFAULT SPI MOSI
 { PORTA, 19, PIO_SERCOM_ALT, PIN_ATTR_DIGITAL, No_ADC_Channel, NOT_ON_PWM, NOT_ON_TIMER, EXTERNAL_INT_3 }, // SERCOM3/PAD[3] - DEFAULT SPI SCK
 // 13..18 - Analog Pins
 // A0
 { PORTA,  2, PIO_ANALOG, PIN_ATTR_ANALOG, ADC_Channel0, NOT_ON_PWM, NOT_ON_TIMER, EXTERNAL_INT_2 }, // ADC/AIN[0]
 // A1
 { PORTA,  4, PIO_ANALOG, (PIN_ATTR_ANALOG|PIN_ATTR_DIGITAL), ADC_Channel4, NOT_ON_PWM, NOT_ON_TIMER, EXTERNAL_INT_4 }, // ADC/AIN[4]
 // A2
 { PORTA,  5, PIO_ANALOG, (PIN_ATTR_ANALOG|PIN_ATTR_DIGITAL), ADC_Channel5, NOT_ON_PWM, NOT_ON_TIMER, EXTERNAL_INT_5 }, // ADC/AIN[5]
 // A3
 { PORTA,  6, PIO_ANALOG, (PIN_ATTR_ANALOG|PIN_ATTR_DIGITAL), ADC_Channel6, NOT_ON_PWM, NOT_ON_TIMER, EXTERNAL_INT_6 }, // ADC/AIN[6]
 // A4
 { PORTA,  7, PIO_ANALOG, (PIN_ATTR_ANALOG|PIN_ATTR_DIGITAL), ADC_Channel7, NOT_ON_PWM, NOT_ON_TIMER, EXTERNAL_INT_7 }, // 9 TCC1/WO[1]
 //A5
 { PORTA,  3, PIO_ANALOG, (PIN_ATTR_ANALOG|PIN_ATTR_DIGITAL), ADC_Channel1, NOT_ON_PWM, NOT_ON_TIMER, EXTERNAL_INT_3 }, // ADC/AIN[1]
 //A6
 //A7
 // WIRE (I2C pins) (SDA/SCL)
 // 19..27 - SPI Pins (MISO,MOSI,SCK)
 // Internal Dotstar Data/Clock
 { PORTA,  0, PIO_SERCOM_ALT, PIN_ATTR_NONE, ADC_Channel4, NOT_ON_PWM, NOT_ON_TIMER, EXTERNAL_INT_4 }, // MOSI: SEROM1/PAD[0]
 { PORTA,  1, PIO_SERCOM_ALT, PIN_ATTR_NONE, ADC_Channel5, NOT_ON_PWM, NOT_ON_TIMER, EXTERNAL_INT_5 }, // SCK: SERCOM1/PAD[1]
 //Same as D5/SWDIO
 { PORTA, 31, PIO_SERCOM_ALT, PIN_ATTR_NONE, No_ADC_Channel, NOT_ON_PWM, NOT_ON_TIMER, EXTERNAL_INT_NONE }, //MISO: SERCOM1/PAD[3]
 // Same as 10 but on Sercom3 - ALT_SPI - MAX6957
 { PORTA, 16, PIO_SERCOM_ALT, PIN_ATTR_DIGITAL, No_ADC_Channel, NOT_ON_PWM, NOT_ON_TIMER, EXTERNAL_INT_0 }, // MISO2-SERCOM3/PAD[0]
 // Same as 11 but on Sercom3 - ALT_SPI - MAX6957
 { PORTA, 18, PIO_SERCOM_ALT, PIN_ATTR_DIGITAL, No_ADC_Channel, NOT_ON_PWM, NOT_ON_TIMER, EXTERNAL_INT_2 }, // MOSI2-SERCOM3/PAD[2]
 // Same as 12 but on Sercom3 - ALT_SPI - MAX6957
 { PORTA, 19, PIO_SERCOM_ALT, PIN_ATTR_DIGITAL, No_ADC_Channel, NOT_ON_PWM, NOT_ON_TIMER, EXTERNAL_INT_3 }, // CLK2-SERCOM3/PAD[3]
 //Sercom0 - DEFAULT SPI (CRMX, RFM69HCW)
 { PORTA,  8, PIO_SERCOM, PIN_ATTR_DIGITAL, No_ADC_Channel, NOT_ON_PWM, NOT_ON_TIMER, EXTERNAL_INT_NMI },  // // MOSI: SERCOM0/PAD[0]
 //Sercom0 - DEFAULT SPI (CRMX, RFM69HCW)
 { PORTA,  9, PIO_SERCOM, PIN_ATTR_DIGITAL, No_ADC_Channel, NOT_ON_PWM, NOT_ON_TIMER, EXTERNAL_INT_9 }, // SCK: SERCOM0/PAD[1]
 //Sercom0 - DEFAULT SPI (CRMX, RFM69HCW)
 { PORTA, 11, PIO_SERCOM, PIN_ATTR_DIGITAL, No_ADC_Channel, NOT_ON_PWM, NOT_ON_TIMER, EXTERNAL_INT_11 }, // MISO: SERCOM0/PAD[3]

 // 28..29 - TX/RX LEDS
 // Same as D3
 { PORTA, 10, PIO_TIMER_ALT, (PIN_ATTR_DIGITAL|PIN_ATTR_PWM|PIN_ATTR_TIMER_ALT), No_ADC_Channel, PWM0_CH2, TCC0_CH2, EXTERNAL_INT_10 }, // LED
 // Same as D5
 { PORTA, 31, PIO_TIMER, PIN_ATTR_DIGITAL, No_ADC_Channel, NOT_ON_PWM, NOT_ON_TIMER, EXTERNAL_INT_NONE }, // LINK_LED

 // 30..32 - USB
 // ----------------------------
 { PORTA, 28, PIO_COM, PIN_ATTR_NONE, No_ADC_Channel, NOT_ON_PWM, NOT_ON_TIMER, EXTERNAL_INT_NONE }, // USB Host enable
 { PORTA, 24, PIO_COM, PIN_ATTR_NONE, No_ADC_Channel, NOT_ON_PWM, NOT_ON_TIMER, EXTERNAL_INT_NONE }, // USB/DM
 { PORTA, 25, PIO_COM, PIN_ATTR_NONE, No_ADC_Channel, NOT_ON_PWM, NOT_ON_TIMER, EXTERNAL_INT_NONE }, // USB/DP
 // 33 - Aref
 { PORTA, 3, PIO_ANALOG, PIN_ATTR_ANALOG, No_ADC_Channel, NOT_ON_PWM, NOT_ON_TIMER, EXTERNAL_INT_NONE }, // DAC/VREFP
 // 34 - Alternate use of A0 (DAC Output)
 { PORTA,  2, PIO_ANALOG, PIN_ATTR_ANALOG, DAC_Channel0, NOT_ON_PWM, NOT_ON_TIMER, EXTERNAL_INT_2 }, // DAC/VOUT
 // 35 & 36 (SWCLK & SWDIO)
 // --------------------------
 { PORTA, 30, PIO_SERCOM_ALT, PIN_ATTR_NONE, No_ADC_Channel, NOT_ON_PWM, NOT_ON_TIMER, EXTERNAL_INT_NONE },
 { PORTA, 31, PIO_SERCOM_ALT, PIN_ATTR_NONE, No_ADC_Channel, NOT_ON_PWM, NOT_ON_TIMER, EXTERNAL_INT_NONE },
 };

const void* g_apTCInstances[TCC_INST_NUM+TC_INST_NUM]={ TCC0, TCC1, TCC2, TC3, TC4, TC5 } ;

// Multi-serial objects instantiation
// Only 0-3 available on E variant!!
SERCOM sercom0( SERCOM0 ) ;
SERCOM sercom1( SERCOM1 ) ;
SERCOM sercom2( SERCOM2 ) ;
SERCOM sercom3( SERCOM3 ) ;


Uart Serial1( &sercom0, PIN_SERIAL1_RX, PIN_SERIAL1_TX, PAD_SERIAL1_RX, PAD_SERIAL1_TX ) ;
Uart Serial2( &sercom1, PIN_SERIAL2_RX, PIN_SERIAL2_TX, PAD_SERIAL2_RX, PAD_SERIAL2_TX ) ;

void SERCOM0_Handler()
{
  Serial1.IrqHandler();
}
